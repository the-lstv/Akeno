/*]

set(deprecated:[ LS Warning ] $name has been deprecated$new. Please update your code.)

default {*/
String.prototype.replaceAll||(String.prototype.replaceAll=function(a,b){return"[object regexp]"===Object.prototype.toString.call(a).toLowerCase()?this.replace(a,b):this.replace(new RegExp(a,"g"),b)});
if(!LS){
    let isWeb = typeof window !== 'undefined', global = isWeb?window:global;
    if(!global.hasOwnProperty("Globalise")){global.Globalise=(...b)=>b.map(a=>typeof(a)=='string'?(()=>global[a]=global?.[a]||null)():Array.isArray(a)?a.map(v=>global[v]=global?.[v]||null):Object.keys(a).map(v=>global[v]=a[v]))}
    var LS={
        isWeb,
        CDN: "http://cdn.extragon.test",
        Util:{
            resolve(...a){
                return a.flat(Infinity).map(i=>{
                    if(i?.tagName)return i;
                    return [...N("temp",i).childNodes];
                }).flat();
            },
            objectPath(o,s,v,splitter,strict=false){
                s=s.replace(/\[(\w+)\]/g,splitter+'$1');
                s=s.replace(new RegExp("^\\"+splitter),'').replace(new RegExp("\\"+splitter+"+","g"),splitter);
                if(s=="")return o;
                let a=s.split(splitter);
                for(let [i,k] of a.entries()){
                    if(k in o){
                        o=o[k];
                    }else{
                        if(strict)return null;
                        o[k]=(i==a.length-1)?v||{}:{};o=o[k];
                        if(i==a.length-1)return o;
                    }
                }
                return o;
            },
            flatten(obj){

            },
            copy(text) {
                return new Promise(r=>{
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(text)
                        .then(() => {
                            r(!0)
                        })
                        .catch(error => {
                            r(!1, error)
                        })
                    } else {
                        //deprecated
                        const _ = N('textarea',{value:text})
                        O().add(_)
                        _.select()
                        D().execCommand('copy')
                        O().removeChild(_)
                        r(!0)
                    }
                })
            },
            /*]
            
            import(
                ls-js/manipulator.js
                : Manipulator : -f
            )
            
            */
        },
        /*]part(tiny)*/
        TinyFactory(r){
            return{
                _affected:!0,
                isElement:!0,
                attr(specific=!1,value=!1){
                    if(value){r.setAttribute(specific,value);return value};
                    if(specific)return r.getAttribute(specific);
                    let a = r.attributes,
                        c = {};
                    Object.keys(a).map(b => c[a[b].nodeName] = a[b].nodeValue);
                    return specific ? c[specific] : c
                },
                attrAssign(a){
                    if(typeof a=="string")a={Array:[a]};
                    if(Array.isArray(a))a={Array:a};
                    Object.keys(a).forEach(k=>{
                        if(k=='Array'){
                            a[k].map(_=>_&&r.setAttribute(_,''));
                            return
                        }
                        (k&&r.setAttribute(k,a[k]||''))
                    })
                },
                hasAttr:r.hasAttribute,
                delAttr(...a){a=a.flat(2);a.forEach(a=>r.removeAttribute(a))},
                class(names,action=1){
                    if(typeof names=="undefined")return [...r.classList];
                    if(typeof names=="string")names=names.split(" ");
                    for(let c of names){
                        r.classList[(action=="add"||(!!action&&action!=="remove"))?(action==2||action=="toggle")?"toggle":"add":"remove"](c)
                    }
                    return r
                },
                hasClass(...names){
                    let h=!0;
                    names=names.flatMap(c=>{
                        if(!r.classList.contains(c))h=!1
                    })
                    return h
                },
                get:(t='*')=>O(r, t),
                getChildern:q=>Q(r.query()+'>'+q||'*'),
                child:i=>r.children[i||0],
                getAll: (t = '*') => Q(r, t),
                add(...a){
                    r.append(...LS.Util.resolve(...a));
                    return r.self
                },
                addBefore(a){
                    LS.Util.resolve(a).forEach(e=>r.parentNode.insertBefore(e,r))
                    return r
                },
                addAfter(a){
                    LS.Util.resolve(a).forEach(e=>r.parentNode.insertBefore(e,r.nextSibling))
                    return r
                },
                addTo(a){
                    O(a).add(r)
                    return r
                },
                setTo(a){
                    O(a).set(r)
                    return r
                },
                move: r.addTo,
                wrapIn(e){
                    r.addAfter(e);
                    e.appendChild(r);
                    return r
                },
                addOnce(a){
                    if (!O('#' + a.id)) r.add(a)
                },
                on(...events){
                    let func=events.find(e=>typeof e=="function");
                    for(const evt of events){
                        if(typeof evt!="string")continue;
                        r.addEventListener(evt,func);
                    }
                    return r.self
                },
                hide(){r.style.display="none"},
                show(c){r.style.display=c||"inherit"},
                applyStyle:(...a)=>S(r.self, ...a),
                getStyle:_=>S(r.self),
                set:(...a)=>{
                    r.innerHTML = '';
                    return r.add(...a)
                },
                clear(){r.innerHTML='';return r},
                setText:(a)=>{
                    r.innerText=a
                },
                has(...a){
                    return !!a.find(l => r.get(l))
                },
                watch:c=>E(r, c),
                parent: (n = 0) => r.tagName == 'BODY' ? r.parentElement : (n > 0 ? O(r.parentElement).parent(n - 1) : r.parentElement),
                findParent(match,limit='html'){
                    return r.path().reverse().find(e=>e.matches(match)||e.matches(limit))
                },
                self:r,
                path:()=>{
                    let p=[r],
                        i=0;
                    while(p[p.length - 1]?.tagName != 'HTML') {
                        p.push(r.parent(i));
                        i++
                    }
                    return p.reverse()
                },
                query:()=>r.path().map(r => r.tagName + (r.className ? '.' + r.className.replace(/\s/g, '.') : '') + (r.id ? '#' + r.id : '')).join('>'),
                queryPath: r.query
            }
        },
        Tiny:{
            Q: (e, q) => {
                let elements = (e?.tagName && !q ? [e] : [...(e?.tagName ? e : D()).querySelectorAll(e?.tagName ? !q ? '*' : q : typeof e == 'string' ? e : '*')])?.map(r => {
                    if(!r._affected){
                        Object.assign(r,LS.TinyFactory(r));
                        if(r.tagName=="BR")r.removeAttribute("clear");
                        Object.defineProperty(r, "loading", {
                            get(){return r.hasAttribute("load")},
                            set(v){r[v?"setAttribute":"removeAttribute"]("load","")},
                        });
                    }
                    return r.self
                }),bulk={
                    all(prop){
                        if(prop)for(const [i,a] of elements.entries()){
                            prop(a,i)
                        }
                        if(!prop){
                            function each(func,...attr){
                                elements.forEach(e=>e[func](...attr))
                            }
                            let r={};
                            for(const name of ['class','attr','add','set','clear','applyStyle','attrAssign','delAttr','on']){
                                r[name]=function(...attr){each(name,...attr)}
                            }
                            return r;
                        }
                    }
                };
                return Object.assign(elements,bulk)
            },
            O: (...e) => {
                e=e.length<1?['body']:e;
                return Q(...e)[0]
            },
            D: () => document,
            N:(e='div',o)=>{
                if(typeof e!="string"){o=e;e="div"}
                o=(typeof o=='string'?{innerHTML:o}:Array.isArray(o)?{inner:o}:o)||{};
                let tmp={};
                if(o.class){tmp.class=o.class;delete o.class}
                if(o.ns){tmp.ns=o.ns;delete o.ns}
                let n=O(Object.assign(D()[tmp.ns?"createElementNS":"createElement"](tmp.ns?tmp.ns:e,tmp.ns?e:null),o));
                if(o.attr)n.attrAssign(o.attr);
                if(tmp.class&&n.class)n.class(tmp.class);
                if(o.style&&typeof o.style=="object")S(n,o.style);
                if(o.inner||o.content)n.add(o.inner||o.content);
                return n
            },
            S:(e,s)=>
                !s?!e?O():(e.id!==void 0)?getComputedStyle(e):
                typeof e=='string'?O(e):Object.keys(e).map(f => f + ':' + e[f]).join(';'):

                (Array.isArray(e) ? e : !e ? [O()] : [e]).forEach(m => {
                    m = typeof m == 'string' ? O(m) : m;
                    Object.assign(m.style, s)
                })
            ,
            E: (b, c) => {
                if (typeof c != 'function') {
                    let _c=c,
                        _b=b;
                    c=()=>{
                        try {
                            O(Q(_b), _c)
                        }catch(e){}
                    };
                    b = O()
                }
                new(window.MutationObserver || window.WebKitMutationObserver)(r => {
                    c([...r[0].addedNodes].map(n => O(n)), [...r[0].removedNodes].map(n => O(n)))
                }).observe(b, {
                    childList: !0,
                    subtree: !0
                });
                return O(b)
            },
            T: (fn, fb, onerror = e => {}) => {
                let r;
                try {
                    r = fn()
                } catch (e) {
                    r = fb;
                    onerror(e)
                }
                return r
            },
            U(url=location.href){
                return Object.assign(new URL(url),{
                    goTo(){location.href=url},
                    open(){open(url)},
                    get segments(){return location.pathname.split("/").filter(s=>s)},
                    async fetch(opt){return await fetch(url,opt)},
                    reload(){location.replace(url)},
                    params(specific=!1){if(!url.includes('?')){return specific?null:{}}let o={};url.replaceAll(/(.*?)\?/gi,'').split('&').forEach(e=>{e=e.split('=');o[e[0]]=decodeURIComponent(e?.[1]).replace(/#(.*)/g,"")});return specific?o[specific]:o}
                })
            },
            M:{x:0,y:0,_GlobalID:{count:0,prefix:Math.round(Math.random()*1e3)},lastKey:null,ShiftDown:!1,ControlDown:!1,mouseDown:!1,on(...events){let func=events.find(e=>typeof e=="function");for(const evt of events){if(typeof evt!="string")continue;global.addEventListener(evt,func)}return M},
                get GlobalIndex(){
                    M._GlobalID.count++;
                    return +((""+M._GlobalID.prefix)+(""+M._GlobalID.count))
                },
                get GlobalID(){return M.GlobalIndex.toString(36)},
                Style(url){
                    return new Promise((r,j)=>{
                        O("head").add(N("link",{rel:"stylesheet",href:url,onload(){r()},onerror(e){j(e.toString())}}))
                    })
                },
                Script(url){
                    return new Promise((r,j)=>{
                        O("head").add(N("script",{src:url,onload(){r()},onerror(e){j(e.toString())}}))
                    })
                },
                Component(...list){
                    list = list.filter(c=>!LS[c])
                    if(list.length<1)return;
                    return M.Script(LS.CDN+"/ls/js/2/@Bare,"+list.join(",").replaceAll(/[ \n/?]/g,""))
                },
                StyleComponent(...list){
                    return M.Style(LS.CDN+"/ls/css/2/@Bare,"+list.join(",").replaceAll(/[ \n/?]/g,""))
                },
                Document(url, target){
                    return new Promise((r,j)=>{
                        fetch(url)
                            .then(async q=>{
                                q = await q.text();
                                (O(target)||O()).add(q);
                                r()
                            })
                            .catch(e=>j(e.toString()))
                    })
                },
                loop(t,...f){
                    for(let i=0;i<t;i++){
                        for(const fn of f){
                            fn(i)
                        }
                    }
                }
            }
        },
        /*]end*/
        async LoadComponents(c){
            for(const D of Object.keys(c)){
                if(LS[D]){console.warn("[LS] Duplicate component name \""+D+"\"");continue};
                function instance(...a){
                    if(LS[D].conf.isFunction)return (LS[D].class({}))(...a);
                    if(a[0] instanceof Element)a[0]=a[0].id||"default";
                    return LS[D].list[a[0]||"default"]||LS[D].new(...a);
                }
                LS[D]=function Component(...a){return instance(...a)};
                LS[D].new=function(id,...a){
                    if(a[0] instanceof Element){
                        a[0]=O(a[0]);
                        if(a[0].attr("ls-component")==D.toLowerCase())return LS[D].list[id]||undefined;
                        a[0].attr("ls-component",D.toLowerCase())
                    }
                    let i=new((LS[D].class)({}))(id,...a);
                    if(LS[D].conf.events)i.Events=new (LS.EventResolver())(i);
                    if(i._init)i._init();
                    if(id)LS[D].list[id]=i;
                    return i
                }
                LS[D].set=function(key,value){LS[D][key]=value};
                LS[D].list={};
                LS[D].conf={};
                LS[D].class=((c[D])(LS[D]));
                let dp=LS[D].conf?.requires;
                if(Array.isArray(dp)){
                    for(const dep of dp){
                        if(!LS[dep]||!c[dep]){
                            if(LS._disableAutomaticDownloading){
                                delete LS[D];
                                LS[D]=false;
                                console.error(`[LS Framework] Unmet dependency of "${D}": "${dep}" ${dp.length>1?`(All dependencies are: ${dp.map(d=>'"'+d+'"').join(", ")})`:''}\nThis component will not work until the dependencies are met.`);
                                break
                            }
                            await M.Component(dep)
                        }
                    }
                    if(!LS[D])break;
                }
                LS[D].conf=Object.assign({batch:!0,events:!0},LS[D].conf);
                if(LS[D].conf.events)LS[D].Events=new (LS.EventResolver())(LS[D]);
                if(LS[D].conf.singular){
                    if(LS[D].conf.becomeClass){LS[D]=LS[D].class;continue};
                    LS[D]=LS[D].new("global");
                }else if(LS[D].conf.batch){
                    LS[D].batch=(e,conf,unique=!0)=>{
                        if(typeof e=="string")e=Q(e);
                        if(!Array.isArray(e))e=[...O(e).children];
                        for(const m of e){
                            new LS[D].new((unique?m.id:null)||"auto_"+M.GlobalID,m,conf)
                        }
                    }
                    LS[D].registerGroup=LS[D].batch;
                    LS[D].observe=(selector,previous,parent=O())=>{
                        if(previous)LS[D].batch(selector);
                        E(parent,async(a,r)=>{
                            for(const m of a){
                                if(m.matches(selector)){
                                    LS[D].new((await LS[D].invoke("observer_element_added",m)).filter(h=>h)[0]||m.id||"observed_"+M.GlobalID,m)
                                }
                            }
                        })
                        return"Observer added for \""+D+"\" looking for any "+selector;
                    }
                }
                if(LS.invoke){
                    LS.invoke("componentLoad", D)
                    LS.invoke("componentLoad:"+D)
                }
            }
        }
    }
    /*]part(tiny)*/
    if(isWeb){
        Globalise(LS.Tiny);
        Object.assign(U,U())
        M.on("mousemove",e=>{M.x=e.clientX;M.y=e.clientY}).on("keydown",e=>{M.lastKey=e.key;if(e.key=="Shift")M.ShiftDown=!0;if(e.key=="Control")M.ControlDown=!0}).on("keyup",e=>{M.lastKey=e.key;if(e.key=="Shift")M.ShiftDown=!1;if(e.key=="Control")M.ControlDown=!1}).on("mousedown",e=>M.mouseDown=!0).on("mouseup",e=>M.mouseDown=!1);
        O(D().documentElement)
        

        if(!global?.dialog)global.dialog=LS.Dialog;
        if(!global?.modal)global.modal=dialog;
        Globalise({
            alert:(m,opt={})=>
                new Promise((r)=>modal(Object.assign({content:m,buttons:[{text:"OK"}],onclose:r},opt))),
            confirm:(m,opt={})=>
                new Promise((r)=>modal(Object.assign({content:m,buttons:[{text:"OK"},{text:"Cancel"}],onclose:b=>r(!b)},opt))),
            prompt:(m,opt={})=>
                new Promise((r)=>modal(Object.assign({content:m+"<br><input placeholder='Enter data' class=ls-modal-prompt type=text ls fluent>",buttons:[{text:"OK"},{text:"Cancel",color:"gray"}],onclose:(c,m)=>r(c!==0?null:m.element.get("input").value)},opt)))
        })
        let loading, loaded;
        M.on("keydown", async(event) => {
            if(loading)return;
            if (event.ctrlKey && event.altKey && event.key === "c") {
                if(!LS.ToolBox && !loaded){
                    loading = true;
                    LS._debugToolBoxShow = true;
                    await M.Component("toolbox")
                    loading = false;
                    loaded = true
                    return
                }
                LS.ToolBox.toggle();
            }
        });
    }
    /*]end*/
}
/*]

end
part(manipulator)*/
String.prototype.manipulate=function(mapper=" *:"){return LS.Util.Manipulate(""+this,mapper)}
String.prototype.manip=String.prototype.manipulate;
/*]end*/

LS.LoadComponents({
    /*]
    set(type::js)

    import(
        ls-js/eventresolver.js
        : EventResolver $type,

        ls-js/modal.js
        : Modal $type,

        ls-js/dialog.js
        : Dialog $type,

        ls-js/tabs.js
        : Tabs $type,

        ls-js/form.js
        : Form $type,

        ls-js/steps.js
        : Steps $type,

        ls-js/navbar.js
        : Navbar $type,

        ls-js/list.js
        : List $type,

        ls-js/select.js
        : Select $type,

        ls-js/debugger.js
        : Debugger $type,

        ls-js/tooltips.js
        : Tooltips $type,

        ls-js/chips.js
        : Chips $type,

        ls-js/tree.js
        : Tree $type,

        ls-js/menubar.js
        : Menubar $type,

        ls-js/present.js
        : Present $type,

        ls-js/notif.js
        : Notif $type,

        ls-js/react.js
        : NanoReact $type,

        ls-js/resize.js
        : Resize $type,

        ls-js/toolbox.js
        : ToolBox $type,

        ls-js/terminal.js
        : Terminal $type,

        ls-js/editor.js
        : Editor $type,

        ls-js/progress.js
        : Progress $type,

        ls-js/color.js
        : Color $type,

        ls-js/graphgl.js
        : GraphGL $type
    )

    part(AccentManager) {
    */
    AccentManager(gl){
        gl.conf = {
            batch: !1,
            singular: !0,
            requires: ["Color"]
        }
        console.warn('/*]set(name:AccentManager)set(new: in favor of Color)print($deprecated)*/')
        return _this=>class AccentManager{
            constructor(){
                return LS.Color
            }
        }
    }
    /*]}*/
});

M.on("load", ()=>{
    Q("[ls-not-ready]").all(e=>e.ready())
})