{
    gl.conf.requires=["Tabs","Form"];
    return(_this)=>class Steps{
        constructor(id,e=O("steps"),o={}){
            _this=this;
            e=O(e);

            this.opt = Object.assign({
                listElement: null,
                doneText: "Done",
                select: "ls-step, step",
                style: "wizzard",
                buttons: true,
                bar: true
            }, o);

            this.form = LS.Form("steps_form_"+id, e, {autoUpdate: true, observe: true});

            console.log(
                Q(this.opt.select)
            );

            this.tabs = LS.Tabs.new("step_tabs_"+id, e, {
                listClass: "ls-steps ls-steps-"+this.opt.style,
                select: this.opt.select,
                listItemClass: this.opt.listItemClass||"ls-steps-item",
                noStyle: true,
                infinite: false,
                listClickable: false,
                listElement: this.opt.listElement,
                bar: this.opt.list,
                ...this.opt.tabOptions
            });

            this.element=e;
            this.stack=[];
            this.values={};
            this.step=0;
            this.stepIndex=this.tabs.tab;

            if(this.opt.buttons){
                console.log(true);
                this.setBackButton(this.opt.buttons.back || null)
                this.setNextButton(this.opt.buttons.next || null)
            }

            this.tabs.on("tab_changed", (i, tab)=>{
                this.stepIndex = i;
                this.invoke("step_changed", i, tab);
                let isRequired = this.tabs.tabs[tab].attr("required");
                this.setCanContinue(!(isRequired&&!this.values[isRequired]));
                let last = i == this.tabs.order.indexOf(this.stack.at(-1));
                this.invoke("last_step_" + (last? "enter" : "leave"))
                if(this.opt.buttons){
                    this.element.getAll(".ls-steps-next[finish-text]").all(e=> e.set(last? e.attr("finish-text") || "Done" : "Next" ))
                    S(this.element.getAll(".ls-steps-previous"), {opacity: i!=0?"1":".4" });
                }
            })

            this.form.on("values_changed",v=>{
                this.values = v;
            })
            this.form.on("change",(key,value,type,element,group)=>{
                if(type !== "radio")return;
                let rq = group.findParent("step").attr("required");

                if(rq)_this.setCanContinue(!!_this.values[rq]);
                _this.updateStack();
            })
        }
        _init(){
            this.reset();
        }
        getValues(){
            return _this.form.get()
        }
        setCanContinue(v=!0){
            if(this.opt.buttons)S(_this.opt.nextBtn,{opacity:v?"1":".4","pointer-events":v?"all":"none"});
        }
        next(){
            if(_this.step == this.stack.length-1) {
                _this.invoke("done",_this.form.get())
            }

            _this.updateStack()
            if(_this.step<_this.stack.length-1) {
                _this.tabs.setActive(_this.stack[(_this.step++)+1])
            }
        }
        previous(){
            _this.updateStack()
            if(!_this.step<1) {
                _this.tabs.setActive(_this.stack[(_this.step--)-1])
            }
        }
        updateStack(){
            _this.stack=[];
            for(const tab of _this.tabs.order){
                let e = _this.tabs.tabs[tab];
                let pass=!(e.attr("if")?e.attr("if").split(";").map(c=>c.split("=")).find(a=>_this.values[a[0]]==a[1]):!0);
                _this.tabs.list[tab].style.display=pass?"none":"";
                if(pass){continue}
                _this.stack.push(tab)
            }
            _this.stack.forEach((e,i)=>{
                e=_this.tabs.list[e];
                e.class(["last-child","only-child","first-child"],0);
                if(_this.stack.length<2){e.class("only-child");return};
                if(i==0)e.class("first-child");
                if(i==_this.stack.length-1)e.class("last-child");
            })
        }
        reset(){
            _this.setCanContinue(!0);
            _this.step=0;
            _this.tabs.setActive(0,1);
            _this.form.reset();
            _this.updateStack()
        }
        setNextButton(element){
            if(!element){
                element = N("button", {innerText: "Next", attr: {"finish-text": "Done"}});
                _this.element.add(element)
            }
            element.class("ls-steps-next")
            element.on("click", ()=>{
                _this.next()
            })
        }
        setBackButton(element){
            if(!element){
                element = N("button", "Previous");
                _this.element.add(element)
            }
            element.class("ls-steps-previous")
            element.on("click", ()=>{
                _this.previous()
            })
        }
    }
}