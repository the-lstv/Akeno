{
    if(!LS.isWeb)return;
    gl.conf={
        batch:!1,
        singular:!0,
        requires:["Resize"]
    }
    return(_this)=>class Console{
        constructor(options={}){
            M.StyleComponent("toolbox", "resize")
            _this=this;
            this.isOpen=false;
            this.config={};
            this.bash={env:{PATH:"/bin",EDITOR:"/bin/nano"},pwd:"/",shell:0,ws:"local"};
            this.localFS={
                bin:{
                    ls(...args){
                        let path = args[1]||_this.bash.pwd, dir = _this.fsGet(path);
                        if(!dir)return _this.error("No such file or directory (\""+path+"\")")
                        if(!dir.dir)return _this.error("\""+path+"\" is a file")
                        _this.log(Object.keys(dir.value).map(e=>typeof dir.value[e]!="object"?`%{#35b1fb}${e}%{#fff}`:e).join("\n"))
                        this.exit()
                    },
                    pwd(){
                        _this.log(_this.bash.pwd)
                        this.exit()
                    },
                    cd(f, path = ""){
                        let dir = _this.fsGet(path);
                        if(!dir||!dir.dir)return _this.error("\""+path+"\" either doesnt exist or is not a directory")
                        _this.bash.pwd=path
                        this.exit()
                    },
                    clear(){
                        _this.lines.clear()
                        this.exit()
                    },
                    mkdir(f, path){
                        _this.fsGet(path, false);
                        this.exit()
                    },
                    touch(f, path){
                        this.exit()
                    },
                    env(){
                        _this.log(Object.keys(_this.bash.env).map(e=>`${e}=${_this.bash.env[e]}`).join("\n"))
                        this.exit()
                    },
                    export(f, e){
                        e = e.split("=")
                        let name = e[0];
                        e.shift()
                        _this.bash.env[name]=e.join("=")
                        this.exit()
                    },
                    echo(f, ...v){
                        _this.log(v.join(" "))
                        this.exit()
                    },
                    make(f, file){
                        this.exit()
                    },
                    nano(f, file){
                        let filename="asd.txt";
                        function draw(){
                            let helpSpacing = " ".repeat(Math.max(0,(_this.lines.cols/2)-16));
                            _this.exec(`clear && echo "%{#000,#fff}  Text Editor  ${" ".repeat((_this.lines.cols/2)-15)}${filename}${" ".repeat(((_this.lines.cols/2)-(filename.length)))}%{/}
%{![${_this.lines.cols},${_this.lines.rows-3}]editor-text}%{/}
%{#000,#fff}^S%{/} Save${helpSpacing}%{#000,#fff}^Z%{/} Undo${helpSpacing}%{#000,#fff}^C%{/} Copy
%{#000,#fff}^X%{/} Exit${helpSpacing}%{#000,#fff}^Y%{/} Redo${helpSpacing}%{#000,#fff}^V%{/} Paste
"`)
                            _this.lines.once("resize",draw)
                        }
                        draw();
                    },
                    async desktop(f, name){
                        let de;
                        function launch(){
                            de
                        }
                        let list=[
                            {id:"LiDE 0.12.1",dir:"lide",cdn:"@lide?"+Math.random()},
                            {id:"Gnome Lite",dir:"gnome-lite",cdn:"@gnome-lite"}
                        ],
                        target = list.find(d=>d.id.toLowerCase().includes(name.toLowerCase())), bin;
                        if(!target){
                            _this.error("Desktop environment \""+name+"\" not found.")
                            return this.exit()
                        }
                        de = _this.fsGet("/env/"+target.dir)
                        if(de){
                            launch();
                            return this.exit()
                        }
                        _this.lines.warn("Desktop environment \""+name+"\" not installed, downloading")
                        _this.log("Preparing to download "+target.id+" to /env/"+target.dir)
                        fetch(LS.CDN+"/file/"+target.cdn)
                            .then(async r=>{
                                _this.log("Checking...")
                                bin = await r.json()
                                if(bin.success===false){
                                    _this.error(bin.error)
                                }else{
                                    _this.fsGet("/env/"+target.dir,false,bin)
                                    _this.log("All done! Launching.")
                                    de = _this.fsGet("/env/"+target.dir)
                                    launch()
                                }
                                this.exit()
                            })
                            .catch(e=>{
                                _this.error(e.toString())
                                this.exit()
                            })
                    }
                }
            }
            this.fs="local"
            this.container = N("div",{class:"ls-debug-console",inner:N("iframe")}).addTo(O())
            this.element = this.container.get("iframe")
            this.win = this.element.contentWindow
            this.doc = this.element.contentDocument || this.win.document
            LS.Resize("ls_console",this.container,[1]).on("resizeend",()=>{
                this.updateConfig("height",LS.Resize("ls_console").values[0])
            })
        }
        _init(){
            this.load()
        }
        updateConfig(k,v){
            if(k)_this.config[k]=v;
            localStorage.lsDebugConsole=JSON.stringify(_this.config)
        }
        loadConfig(){
            if(localStorage.lsDebugConsole){
                _this.config=JSON.parse(localStorage.lsDebugConsole)
            }
            _this.container.style.height=_this.config.height+"px"
            if(LS._debugToolBoxShow){
                _this.open()
                LS._debugToolBoxShow = false
            }else{
                _this[_this.config.open?"open":"close"]()
            }
            if(_this.win.loadConfig)_this.win.loadConfig()
        }
        load(){
            _this.loadConfig()
            _this.win.location.reload()
            _this.win["_this"]=_this;
            _this.doc.open();
            _this.doc.close();
            _this.doc.querySelector("head").appendChild(N("link",{rel:"stylesheet",href:LS.CDN+"/ls/css/0/Base,ls-sharp,toolbox-frame,tabs,present,progress"}))
            _this.doc.querySelector("head").appendChild(N("link",{rel:"stylesheet",href:"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.min.css"}))
            _this.doc.querySelector("head").appendChild(N("script",{src:LS.CDN+"/ls/js/0/tiny,tabs,Terminal,AccentManager,Steps,Present,Progress,Form",onload(){
                _this.win.O().add(N("script",`
                    LS.Tabs('main')
                    let lines = LS.Terminal("lines", O(".lines"))
                    _this.lines=lines
                    _this.log=lines.log
                    _this.print=lines.print
                    _this.error=lines.error
                    function loadConfig(){
                        LS.AccentManager.setGlobal(_this.config.accent||"blue")
                    }
                    loadConfig()
                    O(".lines").click();
                    LS.Present("desktop",O('#desktop'),{fullscreen:true,ignoreEvents:true})
                `))
                _this.log("[ %{red}Welcome%{/} ]\n %{cyan}*%{/} List default commands with \"%{cyan}ls /bin%{/}\" or all commands \"%{cyan}ls -l : $PATH%{/}\"\n %{cyan}*%{/} Access JS with \"%{cyan}js%{/}\" or \"%{cyan}eval ...%{/}\"\n %{cyan}*%{/} Connect to a remote workspace: \"%{cyan}remote name@host%{/}\" (exclude host to use default server)\n %{cyan}*%{/} You can edit files with nano, set variables including PATH etc. same way as in UNIX.\n\nFor more examples and tutorials, run \"%{cyan}man%{/}\".\n")
                _this.win.O().add(N("style",`
                    :root{--color:#fff;--font:Montserrat,Rubik,sans}
                    body{overflow:hidden;height:100vh}
                    .ls-console{position:absolute;bottom:0;left:0;right:0;top:33px;padding:10px;width:calc(100% - 20px);height:unset;--font:"JetBrains Mono",monospace}
                    .ls-console-timestamp{display:none}
                    tab>div{height:calc(100% - 34px);overflow:auto}
                    .setup img{width:130px;border-radius:8px;margin-bottom:10px;pointer-events:none}
                    .setup-de>div{text-align:center;cursor:pointer;padding:10px;border-radius:10px;user-select:none}
                    .setup-de>div:hover{background:#ffffff05}
                    .setup-de>div:active{background:#0004}
                    div .ls-present-body{display:none}
                `))
                _this.win.O().attrAssign(["ls","ls-sharp"])
                _this.exec("init")
                _this.lines.on("newline",(i, v)=>{
                    if(i == "bash-command"){
                        _this.proccess(v)
                    }
                })
            }}))
            _this.doc.body.append(N("tabs",{
                inner:[
                    N("tab",{
                        attr: {"tab-title":"<i class=bi-terminal-fill></i> Terminal"},
                        inner: [N({class:"lines"})]
                    }),
                    N("tab",{
                        attr: {"tab-title":"<i class=bi-wrench></i> Config"},
                        inner: []
                    }),
                    N("tab",{
                        attr: {"tab-title":"<i class=bi-display></i> Desktop"},
                        inner: [N({
                            attr: "chv",
                            inner: "<div class=setup ct><div ls-box ls-yellow><i class=bi-exclamation-triangle-fill></i> You do not have an available desktop yet.</div><br><h3 style=font-weight:100>Choose your desktop</h3><br><div style=gap:10px ch class=setup-de><div onclick=\"LS.Tabs('main').setActive(0);_this.exec('desktop lide',true)\"><img src=https://cdn.extragon.cloud/file/820d268e7d9c435a8fab082ff82c316d.svg><br>LiDE</div><div onclick=\"LS.Tabs('main').setActive(0);_this.exec('desktop gnome',true)\"><img src=https://cdn.extragon.cloud/file/275005127b56c088e7b7179e7695c194.svg><br>Gnome Lite</div></div></div><div id=desktop></div>"
                        })]
                    })
                ]
            }))
        }
        open(){
            if(_this.isOpen)return;
            _this.isOpen=true
            _this.container.class("open")
            _this.invoke("open")
            _this.updateConfig("open",true)
        }
        close(){
            if(!_this.isOpen)return;
            _this.isOpen=false
            _this.container.class("open",0)
            _this.invoke("closed")
            _this.updateConfig("open",false)
        }
        toggle(){
            _this[_this.isOpen?"close":"open"]()
            return _this.isOpen
        }
        fsGet(path="/", strict = true, sv = null){
            if(path.endsWith("/"))path=path.slice(0,-1)
            let t = LS.Util.objectPath(_this.fs=="local"? _this.localFS : this.fs, path, sv, "/", strict)
            return t?{dir: typeof t=="object"?1:0, value: t}:null
        }
        proccess(d){
            switch(_this.bash.shell){
                case 0:
                    _this.exec(d, true)
                break;
                default:
                    _this.handler
            }
        }
        async exec(cmd, isShell){
            if(cmd!="init"){
                //First, parse strings
                let strings = [], inside=false, prev="", str = "", result = "";
                for(let char of cmd){
                    if(char=='"'&&prev!="\\"){
                        inside=!inside;
                    }
                    if(inside){
                        if(char!='"'||prev=="\\")str+=char
                    }else if(str){
                        strings.push(str)
                        str=""
                        result += "%{@}"
                    }else if(char!='"'||prev=="\\"){
                        result += char
                    }
                    prev=char
                }
                strings=strings.map(s=>s.replaceAll("\\\"","\""))
                cmd=result.replace(/#.*$/gm, '').split("&&").map(c=>c.split(" ").filter(g=>g)).filter(g=>g);
                for(let c of cmd){
                    c=c.map(s=>{
                        if(s=="%{@}"){
                            return strings.shift()
                        }
                        return s
                    })
                    let found=0
                    for(let p of _this.bash.env.PATH.split(":")){
                        let dir = _this.fsGet(p)
                        if(!dir||!dir.dir)continue;
                        if(Object.keys(dir.value).includes(c[0])&&typeof dir.value[c[0]]=="function"){
                            try{
                                await new Promise((r,j)=>{
                                    _this.lines.once("ctrlc",r)
                                    dir.value[c[0]].call({
                                        get exit(){return ()=>r(0)},
                                        set exit(v){r(v)}
                                    },...c)
                                })
                            }catch(e){_this.error(e.toString())}
                            found=1
                        }
                    }
                    if(!found){_this.error(c[0]+" not found");break}
                }
            }
            if(isShell||cmd=="init")_this.log(`%{lime}[${_this.bash.ws} ${_this.bash.pwd}]#%{/} %{![*,1]bash-command}`)
        }
    }
}