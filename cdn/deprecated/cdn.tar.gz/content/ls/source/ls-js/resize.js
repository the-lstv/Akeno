{
    let directions = ["top","bottom","left","right"];
    let cursor = ["ns-resize","ns-resize","ew-resize","ew-resize"];
    let values = ["height","height","width","width"];
    return(_this)=>class Console{
        constructor(id, element, sides=[1,1,1,1]){
            _this=this;
            this.sides=sides;
            this.values=[0,0,0,0];
            this.element=O(element);
            this.update();
        }
        update(sides=this.sides){
            _this.sides=Array.isArray(sides)? sides.length < 4 ? [...sides, ...Array(4 - sides.length).fill(0)] : sides.slice(0, 4) : [1,1,1,1];
            sides=_this.sides;
            for(const [i,s] of sides.entries()){
                if(i>3)break;
                this[s?"addHandle":"removeHandle"](i)
            }
        }
        addHandle(side){
            let direction = directions[side];
            if((side>4||side<0)||_this.element.has(".ls-resize-bar-"+direction))return;
            let handle=N({
                class: "ls-resize-bar ls-resize-bar-"+direction
            });
            function move(event) {
                _this.invoke("resize",direction)
                _this.values[side]=((side==0?innerHeight-event.clientY:side==1?event.clientY:side==2?innerWidth-event.clientX:event.clientX))
                _this.element.style[values[side]]=_this.values[side]+"px"
            }
            function release() {
                _this.seeking=false;
                D().documentElement.class("ls-dragging",0)
                D().removeEventListener("mousemove", move);
                D().removeEventListener("mouseup", release);
                D().removeEventListener("touchmove", move);
                D().removeEventListener("touchend", release);
                D().documentElement.style.cursor="";
                _this.invoke("resizeend",direction)
            }
            handle.on("mousedown","touchstart",(e)=>{
                if(e.target!==handle)return;
                _this.seeking=true;
                D().documentElement.class("ls-dragging")
                D().addEventListener("mousemove", move);
                D().addEventListener("mouseup", release);
                D().addEventListener("touchmove", move);
                D().addEventListener("touchend", release);
                D().documentElement.style.cursor=cursor[side];
                _this.invoke("resizestart",direction)
            })
            _this.element.add(handle)
        }
        removeHandle(side){
            let direction = directions[side];
            if((side>4||side<0)||!_this.element.has(".ls-resize-bar-"+direction))return;
            _this.element.get(".ls-resize-bar-"+direction).remove();
        }
    }
}