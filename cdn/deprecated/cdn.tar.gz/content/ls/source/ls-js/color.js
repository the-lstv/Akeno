{
    gl.conf={
        batch:!1,
        singular:!0
    }
    gl.default=["blue","burple","aquamarine","green","lime","orange","yellow","red","bright","pink","purple","gray","gray-light","white","black"];
    return _this=>class Color{
        constructor(){
            _this=this;
            this.colors={};
            this.style=O("#ls-accents");
            if(!this.style){
                this.style=N("style",{id:"ls-accents"});
                if(!O()){
                    M.on("load",()=>O().add(this.style))
                }else{O().add(this.style)}
            }
        }
        add(name,r,g,b){
            if(gl.default.includes(name)||_this.colors[name])return false;
            const hex = r.match(/^#([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i);
            if(hex){
                r=parseInt(hex[1], 16);
                g=parseInt(hex[2], 16);
                b=parseInt(hex[3], 16);
            }else if(typeof r!="number"||typeof g!="number"||typeof b!="number"){
                throw"Invalid color. Supported: hex, rgb"
            }
            _this.colors[name]=[r,g,b]
            _this.style.add(`[ls-${name}],[ls-accent="${name}"]{--accent-raw:${r},${g},${b};--accent-dark-raw:${Math.max(0,r-30)},${Math.max(0,g-30)},${Math.max(0,b-30)}}`)
            return true
        }
        setGlobal(color){
            D().documentElement.setAttribute("ls-accent",color)
        }
    }
}