{
    customElements.define('ls-tabs', class extends HTMLElement {
        constructor(){
            super();
        }
        connectedCallback(){
            this.ready = () => {
                this.ls = LS.Tabs(this.id || M.GlobalID, this)
            }
        }
    });
    return(_this)=>class Tabs{
        constructor(id, e=O("tabs"), opt={}){
            if(typeof e=="string")e=Q(e);
            if(!e)throw"No element provided";
            _this=this;
            this.element=O(e);
            this.tabs={};
            this.order=[];
            this.opt=Object.assign({list:!0,listClass:"",listItemClass:"",listClickable:!0,hide:!0,noStyle:!1,listElement:null,infinite:!0},T(()=>JSON.parse(_this.element.attr("tab-options")),{}),opt);
            if(this.opt.listElement)_this.opt.listElement.className=_this.opt.listElement.className+" tablist "+_this.opt.listClass;
            this.hasList = !!this.opt.list;
            if(this.opt.list){
                this.list={};
                this.listElement=_this.opt.listElement||N("div",{className:"tablist " + _this.opt.listClass + (_this.opt.noStyle?"":" tablist-style")})
                if(!this.opt.listElement)O(e).prepend(this.listElement)
            }
            
            (this.opt.select?
                O(e).getAll(this.opt.select):
                [...O(e).children]
            ).forEach(t=>{
                if(O(t).hasClass("tablist"))return;
                this.addExisting(t)
            })
        }
        _init(){
            _this.setActive(0);
        }
        setActive(tab, force=false){
            if(typeof tab=="number"){
                tab=_this.order[tab]
            }

            let element = _this.tabs[tab],
                index = _this.order.indexOf(tab)

            if(!element)return false;
            if(_this.activeTab==tab&&!force)return true;

            if(_this.opt.list){
                Object.keys(_this.list).forEach(t=>{
                    _this.list[t].class("active",tab == t)
                })
            }

            for(const _tab in _this.tabs){
                let _element = _this.tabs[_tab];
                if(!_element || _tab == tab){
                    continue
                }
                _element.class("tab-active",0)
                if(_this.opt.hide)_element.style.display="none"
            }

            element.style.display=""
            element.class("tab-active")

            _this.element.attr("active-tab", tab)
            _this.activeTab = tab
            _this.tab = index
            _this.invoke("tab_changed", index, tab)
            return true
        }
        addExisting(element, opt = {}){
            return _this.add(null, element, {isReady: true, ...opt})
        }
        add(title, content = N(), opt = {}){
            let e = opt.isReady&&content ?O(content): N("tab",{
                inner:content,
                attr:{"tab-title":title}
            });

            if(!e.hasAttr("tab-title"))e.attr("tab-title", title)

            let id = opt.id||(typeof opt=="string"&&opt)||content.id||e.attr("tab-id")||"tab_"+M.GlobalID;
            e.attr("tab-id", id)

            if(!opt.isReady)_this.element.add(e);
            _this.tabs[id] = e;
            _this.order.push(id);

            _this.addToList(id);
            return id;
        }
        addToList(tab){
            //FIXME: Make it more like "updateList" that updates the order
            if(!_this.opt.list)return;
            let element = _this.tabs[tab], nt=N("div",{
                innerHTML:element.attr("tab-title")||tab,
                attr:{for:tab},
                className:"_tab "+(_this.opt.noStyle?"":"_tab_style ")+_this.opt.listItemClass,
                onclick(){if(_this.opt.listClickable)_this.setActive(tab)}
            });
            _this.list[tab] = nt
            _this.listElement.add(nt)
        }
        remove(id){
        }
        next(){
            _this.tab=_this.tab>_this.length()-2?_this.opt.infinite?0:_this.tab:_this.tab+1;
            _this.setActive(_this.tab)
        }
        previous(){
            _this.tab=_this.tab<1?_this.opt.infinite?_this.length()-1:_this.tab:_this.tab-1;
            _this.setActive(_this.tab)
        }
        length(){
            return _this.tabs.length
        }
    }
}