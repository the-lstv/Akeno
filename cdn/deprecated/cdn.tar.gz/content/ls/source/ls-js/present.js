{
    gl.set("version",2);
    gl.conf.requires=["Steps"];
    return(_this)=>class PresentationView{
        constructor(id,e=O("present"),options={}){
            if(!e)throw"No element found for the presentation.";
            this.opt=Object.assign({resolution:[1280,720],select:"slide"},options);
            e.class("ls-present-container");
            this.element=O(e).wrapIn(N({class:"ls-present-body"}));
            _this=this;
            if(this.opt.frameOnly){
                //...
            }else{
                this.steps=LS.Steps("presentation_steps_"+id,this.element,{listItemClass:"ls-present-bar",tabOptions:{hide:!1},select:options.select,buttons:0})
            }
            S(this.element,{width:this.opt.resolution[0]+"px",height:this.opt.resolution[1]+"px"});
            this.fixResolution();
            M.on("resize",this.fixResolution);
            (this.opt.fullscreen?O():e).on("keydown","wheel",this.handleEvent)
            e.on("click",this.handleEvent)
        }

        handleEvent(e){
            if(_this.opt.ignoreEvents||(_this.lastTimer&&(Date.now()-_this.lastTimer)<((+_this.slideElement().attr("min-time"))||500)))return;
            _this.lastTimer=Date.now();
            if(
                (e.type=="wheel"&&e.deltaY<=0)||
                (e.type=="keydown"&&["ArrowLeft","ArrowUp"].includes(e.key))
            ){
                _this.navigate(-1,false,true);
                return
            }
            _this.navigate(1,false,true);
        }
        slideElement(id=null){
            return _this.steps.tabs.list[_this.steps.tabs.order[id||_this.steps.stepIndex]]
        }
        fixResolution(){
            let e=_this.element,
            scale = Math.min(
                (_this.opt.vpWidth?.()||window.innerWidth) / _this.opt.resolution[0],    
                (_this.opt.vpHeight?.()||window.innerHeight) / _this.opt.resolution[1]
            );
            _this.scale=scale
            e.style.transform=`translate(-50%,-50%) scale(${scale})`;
        }
        navigate(direction,jump=false,key=false){
            if(!jump&&direction==0)return;
            if(!jump&&typeof direction=="string")_this.steps.tabs.order.indexOf(direction);
            let e=_this.slideElement();
            
            let stages=(e.attr("stages")||"").split(";").map(_o=>{
                let o={};
                for(let e of _o.split(",")){
                    if(e.length<1)continue;
                    e=e.split(":");
                    o[e[0]]=e[1];
                }
                return Object.keys(o).length<1?null:o
            }).filter(c=>c),hold=false;

            if(stages.length>0&&!jump){
                let c=e.attr("stage");
                c=+(c||0);
                console.log(c,stages.length,stages,direction);
                if(
                    direction>0?
                        c!=stages.length
                    :
                        c>0
                ){
                    console.warn("asassa");
                    e.attrAssign({stage:c+direction})
                    hold=true
                }
            }
            if(!hold){
                if(direction==1&&key&&e.hasAttr("no-action"))return;
                if(jump){
                    Pr.steps.tabs.setActive(direction);
                }else{
                    _this.steps[direction>0?"next":"previous"]();
                }
            }else{
                _this.invoke("stage",_this.steps.stepIndex,direction,jump);
            }
            _this.invoke("change",_this.steps.stepIndex,_this.steps.tabs.tabs.length,direction,jump);
        }
        next(){
            _this.navigate(1)
        }
        slide(n=0){
            _this.navigate(n,true)
        }
        back(){
            _this.navigate(-1)
        }
        fullscreen(){
            O().requestFullscreen()
        }
    }
}