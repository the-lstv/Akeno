{
    return(_this)=>class Navbar{
        constructor(id,e){
            if(!e)e=O("nav[ls]");
            if(!e.get)e=O(e);
            e.attr("tabindex","-1");
            e.getAll("group").forEach(e=>e.attr("tabindex","-1"));
            e.getAll("items").forEach(i=>{
                i.attr("itemgroup-id",M.GlobalID)
            })
            e.getAll("nav>dropdown,nav>group>dropdown").map(d=>{
                let s=d.tagName;
                d.onmouseenter=()=>{
                    if(typeof d.attr("no-drop")=="string")return;
                    e.getAll(s).forEach(q=>q.classList.remove("active"));
                    d.classList.add("active")
                }
            })
        }
    }
}