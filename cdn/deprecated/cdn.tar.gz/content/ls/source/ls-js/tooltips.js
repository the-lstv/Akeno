{
    return(_this)=>class Tooltips{
        constructor(id,conf){
            this.element=N({class:"ls-tootlip-layer"});
            this.contentElement=N({class:"ls-tooltip-content"});
            this.element.add(this.contentElement);
            O().add(this.element)
            let selector="[ls-tootlip],[ui-tooltip],[tooltip]";
            setInterval(()=>{
                Q(selector).filter(e=>!e._tt).forEach(e=>this.setup(e))
            },400)
        }
        setup(e){
            e._tt=!0;
            e.on("mouseenter",()=>{
                this.element.class("shown");
                this.contentElement.set(e.attr("ls-tooltip")||e.attr("ui-tooltip")||e.attr("tooltip"));
            })
            e.on("mousemove",()=>{
                let box=e.getBoundingClientRect(),cbox=this.contentElement.getBoundingClientRect();
                this.contentElement.applyStyle({
                    left:(
                        Math.min(Math.max(box.left+(box.width/2)-(cbox.width/2),4),innerWidth-(cbox.width))
                    )+"px",
                    maxWidth:(innerWidth-8)+"px",
                    top:"calc("+(box.top-cbox.height)+"px - var(--ui-tooltip-rise,5px))"
                })
            })
            e.on("mouseleave",()=>{
                this.element.class("shown",0)
            })
        }
    }
}