{
    return(_this)=>class Menubar{
        constructor(id,e=O("menubar"),options={}){
            if(!e)throw"No element found for menubar.";
            this.element=O(e);

        }
    }
}