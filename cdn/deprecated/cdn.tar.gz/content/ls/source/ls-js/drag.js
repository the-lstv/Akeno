{
    return _this=>class DragNDrop{
        constructor(){
            
        }
    }
}