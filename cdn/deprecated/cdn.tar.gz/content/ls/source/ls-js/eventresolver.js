{
    gl.conf={
        batch:!1,
        events:!1,
        singular:!0,
        becomeClass:!0
    }
    return(_this)=>class EventClass{
        constructor(target=null){
            this.listeners=[];
            this.events=[];
            _this=this;
            if(target)Object.assign(target,{invoke:this.invoke,on:this.on,once:this.once});
        }
        async invoke(evt,...a){
            let rv=[];
            if(!_this.events.includes(evt))_this.events.push(evt);
            for(const e of _this.listeners.filter(l=>l.for==evt)){
                if(!e)continue;
                rv.push(await e.f(...a));
                if(e.once)delete _this.listeners[e.i];
            }
            return rv
        }
        on(type,evt,extra){
            _this.listeners.push({for:type,f:evt,i:_this.listeners.length,id:M.GlobalID,...extra});
            return _this
        }
        onChain(...events){
            let func=events.find(e=>typeof e=="function");
            for(const evt of events){
                _this.on(evt,func);
            }
        }
        once(type,evt,extra){
            _this.on(type,evt,{once:true,...extra});
            return _this
        }
    }
}