{
    let elementClass = class extends HTMLElement {
        constructor(){
            super();
        }
        connectedCallback(){
            this.ls = LS.Progress(this.id || M.GlobalID, this, {seeker: this.tagName == "LS-SEEKER"})
            this.ls.define(this)
        }
    }
    customElements.define('ls-seeker', elementClass);
    customElements.define('ls-progress', class extends elementClass{constructor(){super()}});

    return _this=>class ProgressBar{
        constructor(id,element,options){
            this.element = element = O(element)
            if(!element)throw"No element provided";

            _this=this;

            element.class("ls-progress");
            element.attrAssign("chv");

            if(options.seeker)this.element.class("ls-seek");
            element.add(N({class:"ls-progress-bar"}),options.seeker?N({class:"ls-seeker-thumb"}):"",N({class:"ls-progress-label",inner:"0 / 0"}))

            _this._min=options.min || +element.attr("min") || 0;
            _this._max=options.max || +element.attr("max") || 100;
            _this._progress=options.progress || 0;
            _this._value=options.value || +element.attr("value") || 0;

            this.define(this)
            this.options = options
            if(options.progress&&options.value)throw("You can't define both the progress and value.")
        }
        _init(){
            _this.bar=_this.element.get(".ls-progress-bar");
            _this.label=_this.element.get(".ls-progress-label");
            if(_this.options.seeker){
                _this.thumb=_this.element.get(".ls-seeker-thumb");
                function moveThumb(event) {
                    let rect = _this.element.getBoundingClientRect(),
                        xOffset = (event.type == "touchmove" ? event.touches[0].clientX : event.clientX) - rect.left,
                        newValue = (xOffset/rect.width)*_this.max
                    ;
                    if (newValue>=0&&newValue<=_this.max) {
                        _this._value=newValue;
                        _this.update(false,true)
                    }
                }
                function releaseThumb() {
                    _this.seeking=false;
                    _this.element.class("is-dragging", 0)
                    O().class("ls-dragging", 0)
                    D().removeEventListener("mousemove", moveThumb);
                    D().removeEventListener("mouseup", releaseThumb);
                    D().removeEventListener("touchmove", moveThumb);
                    D().removeEventListener("touchend", releaseThumb);
                    _this.invoke("seekend",_this._value,_this._max,_this._progress)
                }
                _this.element.on("mousedown","click","touchstart",(e)=>{
                    if(_this.element.hasAttr("disabled"))return;
                    if(e.target!==_this.element&&e.target!==_this.bar&&e.target!==_this.thumb)return;
                    if(e.type=="click"){
                        return moveThumb(e)
                    }
                    _this.seeking=true;
                    _this.element.class("is-dragging")
                    O().class("ls-dragging")
                    D().addEventListener("mousemove", moveThumb);
                    D().addEventListener("mouseup", releaseThumb);
                    D().addEventListener("touchmove", moveThumb);
                    D().addEventListener("touchend", releaseThumb);
                    _this.invoke("seekstart",_this._value,_this._max,_this._progress)
                })
            }
            if(_this.options.progress&&!_this.options.value){_this.update(true)}
            else if(_this.options.value&&!_this.options.progress){_this.update()}
            else{_this.update()}
        }
        define(scope){
            Object.defineProperty(scope,"progress",{
                get(){return _this._progress},
                set(value){_this._progress=value;_this.update(true)}
            })
            Object.defineProperty(scope,"value",{
                get(){return _this._value},
                set(value_){_this._value=value_;_this.update()}
            })
            Object.defineProperty(scope,"max",{
                get(){return _this._max},
                set(value){_this._max=value;_this.update()}
            })
        }
        update(setPercentage,isSeeking){
            if(_this.seeking&&!isSeeking)return;
            if(!setPercentage){
                _this._progress=(_this.value/_this.max)*100
            }else{
                _this._value=(_this._progress*_this.max)/100
            }
            if(_this.options.seeker){
                _this.thumb.style.left=_this.progress+"%"
                if(isSeeking)_this.invoke("seek",_this._value,_this._max,_this._progress)
            }
            _this.bar.style.width=_this.progress+"%"
            _this.label.set(_this.options.template?_this.options.template(this):_this.options.seeker?[N({innerText:String(_this.value)}),N({innerText:String(_this.max)})]:`${_this.value} / ${_this.max}${_this.options.metric?" "+_this.options.metric:""}`)
        }
    }
}